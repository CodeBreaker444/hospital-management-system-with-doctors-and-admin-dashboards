
-- --------------------------------------------------------

--
-- Table structure for table `hms`
--

CREATE TABLE `hms` (
  `ID` int(11) NOT NULL,
  `doc_type` int(30) NOT NULL,
  `s_firstname` varchar(30) NOT NULL,
  `s_lastname` varchar(30) NOT NULL,
  `s_sex` varchar(30) NOT NULL,
  `s_phone` bigint(12) NOT NULL,
  `s_mail` varchar(30) NOT NULL,
  `slot_date` varchar(30) NOT NULL,
  `slot_time` varchar(30) NOT NULL,
  `hlth_desc` varchar(35) NOT NULL,
  `status` int(5) NOT NULL,
  `posting_date` varchar(30) NOT NULL,
  `s_ip` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hms`
--

INSERT INTO `hms` (`ID`, `doc_type`, `s_firstname`, `s_lastname`, `s_sex`, `s_phone`, `s_mail`, `slot_date`, `slot_time`, `hlth_desc`, `status`, `posting_date`, `s_ip`) VALUES
(1, 1, ' Priya', 'Sasanapuri', 'Ms.', 2147483647, 'priya@gmail.com', '2017-07-19', '9-10AM', 'fever', 0, '', ''),
(2, 3, 'Harika Devi', 'Surada', 'Ms.', 2147483647, 'harika@gmail.com', '2017-07-19', '11-12AM', 'soo much pain ', 0, '', ''),
(4, 3, 'viswas', 'patro', 'Mr.', 2147483647, 'vissu@gmail.com', '2017-07-20', '2-3PM', 'tooth cavity', 0, '', ''),
(5, 4, 'Lalasa', 'sasanapuri', 'Ms.', 2147483647, 'lallu@gmail.com', '2017-07-26', '4-5PM', 'low blood pressure', 0, '', ''),
(7, 2, 'Gowri', 'Sita', 'Ms.', 7894561320, 'gowri@gmail.com', '2017-07-19', '9-10AM', 'Cold', 0, '', ''),
(8, 1, 'akhil', 'sudia', 'Mr.', 8654785446, 'akhil@gmail.com', '2017-07-20', '11-12AM', 'viral fever', 0, '', '');
