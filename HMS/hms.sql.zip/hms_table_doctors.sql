
-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `ID` int(20) NOT NULL,
  `doc_name` varchar(35) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`ID`, `doc_name`, `username`, `password`) VALUES
(1, 'Dr.Arjun Kumar', 'doctor1', 'doctor1'),
(2, 'Dr.Dev Patel', 'doctor2', 'doctor2'),
(3, 'Dr.Mary', 'doctor3', 'doctor3'),
(4, 'Dr.Priyanka Chowdary', 'doctor4', 'doctor4');
